$(document).ready(function() {
  $('#addSubject').click(function() {
    var subjectCount = $('.subject-div').length + 1;
    var newSubjectDiv = '<div class="subject-div"><label for="subject' + subjectCount + '">Subject ' + subjectCount + ':</label><input type="number" class="form-control subject" min="0" max="100" required></div>';
    $('#subjectInputs').append(newSubjectDiv);
  });

  $('#calculateButton').click(function() {
    calculateGrades();
  });
});

function calculateGrades() {
  var totalGrade = 0;
  var totalPercentage = 0;
  var totalAverage = 0;

  var studentName = $('#studentName').val();
  if (studentName === "") {
    alert("Please enter the student name.");
    return;
  }

  $('.subject-div').each(function(index) {
    var grade = parseFloat($(this).find('.subject').val());
    if (!isNaN(grade)) {
      totalGrade += grade;
      var result = '';

      if (grade >= 75 && grade <=100) {
        result = 'pass';
      } else if (grade >= 69 && grade <=74) {
        result = 'remedial';
      } else if (grade >= 51 && grade <=68 ) {
        result = 'fail';
      } else {
        result = 'invalid';
      }

         var resultDiv = '<div class="result-div ' + result + '">Result: ' + result + '</div>';
        $(this).append(resultDiv);
            }
        });

        var subjectCount = $('.subject').length;
        if (subjectCount > 0) {
            totalPercentage = (totalGrade / (subjectCount * 100)) * 100;
            totalAverage = totalGrade / subjectCount;
        }

        $('#totalGrade').text(totalGrade);
        $('#totalPercentage').text(totalPercentage.toFixed(2));
        $('#totalAverage').text(totalAverage.toFixed(2));
        $('#result').show(); 

        $('#studentName').val("");
       
}

