function calculateSum() {
    var numbers = document.getElementsByClassName('numberInput');
    var sum = 0;
    
    for (var i = 0; i < numbers.length; i++) {
      sum += parseInt(numbers[i].value);
    }
    
    document.getElementById('result').innerHTML = 'Sum: ' + sum;
  }
//  end of sum array -------------------------------------------------------------

function displayDescendingOrder() {
    const numbersInput = document.getElementById('numbers');
    const numbers = numbersInput.value.split(',').map(Number);
    const sortedNumbers = numbers.sort((a, b) => b - a);
    
    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = "<strong>Descending Order:</strong> " + sortedNumbers.join(', ');
  }
// end of Array and Display Decreasing order---------------------------------------

function findGreatestNumber() {
    var numbersInput = document.getElementById('numbers');
    var numbers = numbersInput.value.split(',').map(Number);
  
    var greatestNumber = Math.max.apply(null, numbers);
    
    var resultDiv = document.getElementById('result');
    resultDiv.innerHTML = 'The greatest number is: ' + greatestNumber;
  }

// end offind the Greatest Number--------------------------------------------------
 // Prevent form submission
document.getElementById("numberForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    var numbers = [];
    
    // to retrieve values from input fields
    for (var i = 1; i <= 10; i++) {
      var inputId = "number" + i;
      var number = Number(document.getElementById(inputId).value);
      numbers.push(number);
    }
    
    // to calculate average
    var sum = numbers.reduce(function(a, b) {
      return a + b;
    }, 0);
    
    var average = sum / numbers.length;
    
    // to display the average
    document.getElementById("result").textContent = "Average: " + average.toFixed(2);
  });
// end ofDisplay Average  
function displayIndices() {
    // Get the numbers input element
    var numbersInput = document.getElementById('numbersInput');
  
    // Get the input value
    var inputNumbers = numbersInput.value;
  
    // Split the input value by comma to get individual numbers
    var numbers = inputNumbers.split(',');
  
    // Trim whitespace from each number
    numbers = numbers.map(function (num) {
      return num.trim();
    });
  
    // Get the output div element
    var outputDiv = document.getElementById('output');
  
    // Clear previous content
    outputDiv.innerHTML = '';
  
    // Iterate over the numbers array and display the indices
    for (var i = 0; i < numbers.length && i < 10; i++) {
      var index = "[" + i + "]";
      outputDiv.innerHTML += index + " ";
    }
  }
//   Array and display the index between [0] and [9]