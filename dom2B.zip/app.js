const numberArr = [];



let stringInput = "";
let stringArr = [];


function functionString(){ 
    stringInput = document.getElementById("textarea").value;
    stringArr = stringInput.split(" ");

    reqTwoA();
    reqtwoB();   
    reqtwoC();
    reqTwoD();
    reqTwoE();
    reqTwoF();
    reqTwoG();
    reqTwoH();
    reqTwoI();
    reqTwoJ();
    reqTwoK();
    reqTwoL();
}

function functionNumbers(){
    var first  = parseInt(document.getElementById("first").value);
    var second  = parseInt(document.getElementById("second").value);
    var third  = parseInt(document.getElementById("third").value);
    var fourth  = parseInt(document.getElementById("fourth").value);
    var fifth  = parseInt(document.getElementById("fifth").value);
    var sixth  = parseInt(document.getElementById("sixth").value);
    var seventh  = parseInt(document.getElementById("seventh").value);
    var eight  = parseInt(document.getElementById("eight").value);
    var ninth  = parseInt(document.getElementById("ninth").value);
    var tenth  = parseInt(document.getElementById("tenth").value);

    numberArr.push(first, second, third, fourth, fifth, sixth, seventh, eight, ninth, tenth);
    reqOneA();
    reqOneB();
    reqOneC();
    reqOneD();
    reqOneE();
    reqOneF();
}

function reqTwoA(){
    document.getElementById("firstString").innerHTML = "Display string of array: <br> ";
    for(let i=0;i<stringArr.length;i++){
        document.getElementById("firstString").innerHTML += stringArr[i] + "<br>";
    }
}

function reqtwoB(){
    let charCount = 0;
    let numCount = 0;
    let nonNumCount = 0;

    for(let char of stringInput){
        if(char >= "A" && char <= "Z" ||char >= "a" && char <= "z"){
            charCount++;
        }else if(char >= "0" && char <= "9"){
            numCount++;
        }else{
            nonNumCount++;
        }       
    }
    document.getElementById("secondString").innerHTML = " Number of characters: " + charCount + "<br>" + " Number of numbers: " + numCount + "<br>" + " Number of non numbers: " + nonNumCount;
}

function reqtwoC(){
    reverseWord = []; 
    storeArr = [];
    storeString = "";
    for(let i=0;i<stringArr.length;i++){
        storeArr = stringArr[i].split("");
        storeArr.reverse();
        storeString = storeArr.join("");
        reverseWord.push(storeString);
    }
    document.getElementById("thirdString").innerHTML = "Display every element in reverse: <br>";
    for(let i=0;i<reverseWord.length;i++){
        document.getElementById("thirdString").innerHTML += reverseWord[i] + "<br>";
    }
}

function reqTwoD(){
    reverseWord = [];
    storeArr = [];
    storeString = "";
    for(let i=0;i<stringArr.length;i++){
        storeArr = stringArr[i].split("");
        storeArr.reverse();
        storeString = storeArr.join("");
        reverseWord.push(storeString);
    }
    document.getElementById("fourthString").innerHTML = "Given String: test 1 and 0 <br>";
    reverseWord.reverse();
    for(let i=0;i<reverseWord.length;i++){
        document.getElementById("fourthString").innerHTML += reverseWord[i] + " ";
    }
}

function reqTwoE(){
    var addOne = [];
    var text = stringInput;
    for(var i=0; i<text.length; i++){
    addOne.push( String.fromCharCode(text.charCodeAt(i) + 1));
    }
    document.getElementById("fifthString").innerHTML = addOne.join('');
}

function reqTwoF(){
    document.getElementById("sixthString").innerHTML = stringInput.toUpperCase();
}

function reqTwoG(){
    document.getElementById("seventhString").innerHTML = stringInput.toLowerCase();
}

function reqTwoH(){
    upperCount = 0;
    lowerCount = 0;
    nonCount = 0;

    for(let char of stringInput){
        if(char >= "A" && char <= "Z"){
            upperCount++;
        }else if(char >= "a" && char <= "z"){
            lowerCount++;
        }else{
            nonCount++;
        }
    }
    document.getElementById("eightString").innerHTML = `
    String Length = `+stringInput.length+` <br>
    Number of uppercase: `+ upperCount+` <br>
    Number of lowercase: `+lowerCount+` <br>
    Number of lowercase: `+nonCount;
}

function reqTwoI(){
    let string = "";
    for(let char of stringInput){
        string += char + "<br>";
    }
    document.getElementById("tenthString").innerHTML = string;
}

function reqTwoJ(){
    let tempArr = stringInput.split("");
    let string = "";
    tempArr.splice(0,1);
    string = tempArr.join("");
    document.getElementById("eleventhString").innerHTML = string;
}

function reqTwoK(){
    document.getElementById("twelveString").innerHTML = stringInput.replace('a', '$');
}

function reqTwoL(){
    let initialText = stringInput;
    let origText = initialText;
    let copyText = origText.valueOf();
    let first = ("The string value is: " + origText);
    let second = ("String After copied: " + copyText);

    var all = first + "<br>" + second;    

    document.getElementById("thirteenthString").innerHTML = all;
}